
*Person sample code in Eiffel*

This code was tested on the platform here:

https://codeboard.io/projects/176062

Some references that helped me run this sample code.

* [https://www.eecs.yorku.ca/~jackie/teaching/lectures/2018/F/EECS3311/slides/02.1-Eiffel-vs-Java.pdf](https://www.eecs.yorku.ca/~jackie/teaching/lectures/2018/F/EECS3311/slides/02.1-Eiffel-vs-Java.pdf)
* [https://www.eecs.yorku.ca/~jackie/teaching/lectures/2020/W/EECS3311/blackboards/Blackboard%20-%20EECS3311%20-%20W20%20-%2020200113.pdf](https://www.eecs.yorku.ca/~jackie/teaching/lectures/2020/W/EECS3311/blackboards/Blackboard%20-%20EECS3311%20-%20W20%20-%2020200113.pdf) (slide 18)
* [https://www.youtube.com/watch?v=j1GMls7MqsQ&list=PL5dxAmCmjv_5O2hx1ARzjI5LQhkX477bw&index=25&t=0s](https://www.youtube.com/watch?v=j1GMls7MqsQ&list=PL5dxAmCmjv_5O2hx1ARzjI5LQhkX477bw&index=25&t=0s)
* [https://www.youtube.com/watch?v=ovBNk6uNQDM&index=1&list=PL5dxAmCmjv_6r5VfzCQ5bTznoDDgh__KS](https://www.youtube.com/watch?v=ovBNk6uNQDM&index=1&list=PL5dxAmCmjv_6r5VfzCQ5bTznoDDgh__KS)
* [https://www.youtube.com/watch?v=UTUqj719Eas&index=2&list=PL5dxAmCmjv_6r5VfzCQ5bTznoDDgh__KS](https://www.youtube.com/watch?v=UTUqj719Eas&index=2&list=PL5dxAmCmjv_6r5VfzCQ5bTznoDDgh__KS)
* [https://www.eecs.yorku.ca/~jackie](https://www.eecs.yorku.ca/~jackie)
* [https://www.eecs.yorku.ca/~jackie/teaching/tutorials/index.html#dbc_tdd](https://www.eecs.yorku.ca/~jackie/teaching/tutorials/index.html#dbc_tdd)