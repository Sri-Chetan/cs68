# Code related to recursion

* Factorial and Fibonacci

Code for factorial and fibonacci with exceptions

* Evaluation of recurisve functions

Code to check if a programming language uses innermost or outermost evaluation of recursive functions. We use the following function: f(n,m) = if n = 0 then 0 else f(n-1, f(n,m)) 
n, m >= 0 and compute f(1,1)

